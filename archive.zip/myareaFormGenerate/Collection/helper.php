<?php
function collect($data){
    return new SiLibrary\Collection($data);
}