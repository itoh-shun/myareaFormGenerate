<?php 
require_once 'Collection/require.php';
require_once 'SpiralConnecter/Request/HttpRequestParameter.php';
require_once 'SpiralConnecter/XSpiralApiHeaderObject.php';
require_once 'SpiralConnecter/SpiralConnecterInterface.php';
require_once 'SpiralConnecter/SpiralManager.php';
require_once 'SpiralConnecter/OrderBy.php';
require_once 'SpiralConnecter/Paginator.php';
require_once 'SpiralConnecter/Request/HttpRequest.php';
require_once 'SpiralConnecter/SpiralApiConnecter.php';
require_once 'SpiralConnecter/SpiralConnecter.php';
require_once 'SpiralConnecter/SpiralDB.php';
require_once 'SpiralConnecter/SpiralExpressManager.php';
require_once 'SpiralConnecter/SpiralFilterManager.php';
require_once 'SpiralConnecter/SpiralRedis.php';
require_once 'SpiralConnecter/SpiralWeb.php';
require_once 'SpiralConnecter/SpiralWebManager.php';
require_once 'SpiralConnecter/helper.php';
