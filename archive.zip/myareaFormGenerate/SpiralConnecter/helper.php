<?php
if(!function_exists('spiral')){
    function spiral(){
        global $SPIRAL;
        return $SPIRAL;
    }
}
