<?php
require_once 'Collection/require.php';
require_once 'SpiralConnecter/require.php';
require_once 'SiValidator2/require.php';
require_once 'FormGenerate/Renderer/Bootstrap5Renderer.php';
require_once 'FormGenerate/Renderer/DefaultRenderer.php';
require_once 'FormGenerate/Helper/SanitizeHelper.php';
require_once 'FormGenerate/Helper/FieldRenderer.php';
require_once 'FormGenerate/FormBuilder.php';