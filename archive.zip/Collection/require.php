<?php
require_once 'Collection/Traits/AggregatesItemsTrait.php';
require_once 'Collection/Traits/ArrayableTrait.php';
require_once 'Collection/Traits/ComparisonTrait.php';
require_once 'Collection/Traits/ManipulationTrait.php';
require_once 'Collection/Traits/OperatesOnItemsTrait.php';
require_once 'Collection/Traits/PaginationTrait.php';
require_once 'Collection/Traits/PropertyAccessTrait.php';
require_once 'Collection/Traits/SearchTrait.php';
require_once 'Collection/Traits/TransformationTrait.php';
require_once 'Collection/Collection.php';
require_once 'Collection/helper.php';